package Credentials;
import java.util.*;

public class Login extends Signup{
    
    protected String loginPass;

    protected String loginEmail;
    Scanner sc = new Scanner(System.in);
    public void EnterLoginDetails(){
        System.out.println("*******************Enter the login details********************");
        System.out.println("Enter the Email to login");
        loginEmail = sc.nextLine();
        System.out.println("Enter login Pass");
        loginPass = sc.nextLine();


    }
    public boolean check()
    {
        if((loginEmail.equals(signUpEmail)) && (loginPass.equals(signUpPassword))){
           System.out.println("***********************Welcome " + Name +"****************************");
            return true;
        }
        else
        System.out.println("Incorrect login details");
        return false;
    }
}