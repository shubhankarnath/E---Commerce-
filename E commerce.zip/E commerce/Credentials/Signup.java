package Credentials;
import java.util.*;

public class Signup{
    
    protected String signUpEmail;
    protected String signUpPassword;
    protected String Name;
    Scanner sc = new Scanner(System.in);

    public void SignUp(){
        System.out.println("Enter your Name");
        Name = sc.nextLine();
        System.out.println("Enter the Email to register");
        signUpEmail = sc.nextLine();
        System.out.println("Enter the password");
        signUpPassword = sc.nextLine();
        System.out.println("************Sign Up completed!**************");



    }




}