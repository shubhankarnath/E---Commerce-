package Items;

import java.util.*;

public class AvailableBooks extends Price implements Rating {
    Scanner in = new Scanner(System.in);

    public void ListOfBooks() {
        System.out.println("Books Available : ");
        System.out.println("1. Java Expert : ");
        System.out.println("2. Java Balaguruswamy ");
        System.out.println("3. Core Java and Advanced Java ");
        System.out.println("4. Think and Grow Rich ");
        System.out.println("5. E Balagurswamy Data Structure ");
        System.out.println("6. Java : The Complete Reference ");
        System.out.println("7. Data Structures And Algorithms Made Easy ");
        System.out.println("8. Cracking the Coding Interview (Indian Edition) ");
        System.out.println("9. Advanced Data Structures & Algorithms in C++l ");
        System.out.println("______________________________________________________________");

        System.out.println("Enter the choice number of your book");

        int choice = in.nextInt();
        switch (choice) {
        case 1:
            System.out.println("Price of Java Expert : " + Java_Expert);
            break;
        case 2:
            System.out.println("Price of Java Balaguruswamy : " + Java_Balagurus);
            break;
        case 3:
            System.out.println("Price of Core Java and Advanced Java : " + Core_Java_and_Advanced);
            break;
        case 4:
            System.out.println("Price of Think and Grow Rich : " + Think_and_Grow);
            break;
        case 5:
            System.out.println("Price of E Balagurswamy Data Structure : " + E_Balagurswamy_DSA);
            break;
        case 6:
            System.out.println("Price of Java : The Complete Reference : " + The_Complete_Refer);
            break;
        case 7:
            System.out.println("Price of Data Structures And Algorithms Made Easy : " + DSA_Easy);
            break;
        case 8:
            System.out.println("Price of Cracking the Coding Interview (Indian Edition) : " + Coding_Interview);
            break;
        case 9:
            System.out.println("Price of Advanced Data Structures & Algorithms in C++ : " + Advanced_DSA);
            break;
        default:
            System.out.println("Wrong Input!");
        }
        System.out.println("_____________________________________________________________________________________________________");
        
        System.out.println(" ---------------------");
        System.out.println("|Do you want to buy ? |");
        System.out.println(" ---------------------");
        System.out.println("_______________");
        System.out.println("Press 1 to Buy");
        System.out.println("_______________");
        System.out.println("1. Yes");
        System.out.println("2. No");
        int buy = in.nextInt();

        if (buy == 1) {
            System.out.println("*************************---------------------*******************************");
            System.out.println("***********************|  Buying Successful!  |******************************");
            System.out.println("*************************---------------------*******************************");
        } else {
            System.out.println("We will be waiting for you! Come back Soon");
        }
    }

    public void RateUs() {

        System.out.println("On the scale of 1 to 5, Please rate our Books.");
        int r = in.nextInt();
        System.out.println("___________________________________________________________");
        System.out.println("Your rated " + r + " out of 5. Thankyou for your feedback");
        System.out.println("___________________________________________________________");
    }

    public void Greet() {
        System.out.println(" ____________________________________");
        System.out.println("|THANKYOU AND HAVE A GREAT DAY HEAD! |");
        System.out.println(" ____________________________________");
    }

}
