package Items;
import java.util.*;

public class AvailableClothes extends Price implements Rating {
    Scanner in = new Scanner(System.in);
    public void ListOfClothes(){
        System.out.println("Clothes Available : ");
        System.out.println("1. Jeans : ");
        System.out.println("2. T-Shirt ");
        System.out.println("3. Shawl ");
        System.out.println("4. Lehenga Cholis ");
        System.out.println("5. Sarees ");
        System.out.println("6. Sleepwear ");
        System.out.println("7. Tracksuits ");
        System.out.println("8. Jackets ");
        System.out.println("9. Sweaters ");
        System.out.println("---------------------------------------------------------------------------");

        System.out.println("Enter the choice number of your Clothes ");
        
        int choice = in.nextInt();
        try{
        switch (choice) {
        case 1:
            System.out.println("Price of Jeans : " + Jeans);
            break;
        case 2:
            System.out.println("Price of T-Shirt : " + T_Shirt);
            break;
        case 3:
            System.out.println("Price of Shawl : " + Shawl);
            break;
        case 4:
            System.out.println("Price of Lehenga Cholis : " + Lehenga_Cholis);
            break;
        case 5:
            System.out.println("Price of  Sarees : " + arees);
            break;
        case 6:
            System.out.println("Price of Sleepwear : " + Sleepwear);
            break;
        case 7:
            System.out.println("Price of Tracksuits : " + Tracksuits );
            break;
        case 8:
            System.out.println("Price of Jackets : " + Jackets);
            break;
        case 9:
            System.out.println("Price of Sweaters : " + Sweaters);
            break;
        
        }
    }
    catch(Exception e){
        System.out.println("Invalid Number entered");
        e.printStackTrace();
        
        
    }
    
        System.out.println("************************************************************************************************************");

        System.out.println("Do you want to buy ? Press 1:");
        System.out.println("************************************************************************************************************");
        System.out.println("1. Yes");
        System.out.println("2. No");
        int buy = in.nextInt();
        
                if(buy == 1)
                {   System.out.println(""); System.out.println("");
                    System.out.println("*************************---------------------*******************************");
            System.out.println("***********************|  Buying Successful!  |******************************");
            System.out.println("*************************---------------------*******************************");
                    
                }
                else
                {
                    System.out.println("We will be waiting for you! Come back Soon");
                }
    }
    public void RateUs(){
        System.out.println("");
        System.out.println("");
        System.out.println("On the scale of 1 to 5, Please rate our Clothes.");
        int r = in.nextInt();
        System.out.println("************************************************************************************************************");
        System.out.println("Your rated " + r + " out of 5. Thankyou for your feedback");
        System.out.println("************************************************************************************************************");
    }
    public void Greet(){
        System.out.println("THANKYOU AND HAVE A GREAT DAY HEAD! ");
    }

}