
package Items;
import java.util.*;

public class AvailableGroceries extends Price{
    Scanner in = new Scanner(System.in);
    public void ListofGroceriess(){
        System.out.println("Available Groceries : ");
        System.out.println("1. Wah Taj - Tea : ");
        System.out.println("2. Nestle Coffee ");
        System.out.println("3. Maggie Noodles ");
        System.out.println("4. Amul Cheese ");
        System.out.println("5. Biscuits ");
        System.out.println("6. Aashirwaad Aatta/Floor ");
        System.out.println("---------------------------------------------------------------------------");
        

        System.out.println("Enter the choice number of your TV");
        
        int choice = in.nextInt();
        switch(choice){
            case 1: 
            System.out.println("Price of 100g Wah Taj - Tea : Rs. " + Tea);
            break;
            case 2: 
            System.out.println("Price of 100g Nestle Coffee : Rs.Rs.  " + Coffee);
            break;
            case 3: 
            System.out.println("Price of 100g Maggie Noodles : Rs. " + Maggie);
            break;
            case 4: 
            System.out.println("Price of 500g Amul Cheese : Rs. " + Cheese);
            break;
            case 5: 
            System.out.println("Price of Oreo Biscuits : Rs. " + Biscuits);
            break;
            case 6: 
            System.out.println("Price of 4 kg Aashirwaad Aatta/Floor : Rs. " + Aatta);
            break;
            

        }
        System.out.println("************************************************************************************************************");

        System.out.println("Do you want to buy ? Press 1:");
        System.out.println("************************************************************************************************************");
        System.out.println("1. Yes");
        System.out.println("2. No");
        int buy = in.nextInt();
        
                if(buy == 1)
                {
                    System.out.println("*************************---------------------*******************************");
            System.out.println("***********************|  Buying Successful!  |******************************");
            System.out.println("*************************---------------------*******************************");
                }
                else
                {
                    System.out.println("We will be waiting for you! Come back Soon");
                }
    }
    public void RateUs(){
        
        System.out.println("On the scale of 1 to 5, Please rate our Groceries.");
        int r = in.nextInt();
        System.out.println("************************************************************************************************************");
        System.out.println("Your rated " + r + " out of 5. Thankyou for your feedback");
        System.out.println("************************************************************************************************************");
    }
    public void Greet(){
        System.out.println("THANKYOU AND HAVE A GREAT DAY HEAD! ");
    }
}
