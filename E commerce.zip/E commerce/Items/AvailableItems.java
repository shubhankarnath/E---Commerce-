package Items;
public class AvailableItems {
public void showAvailableItems(){
    System.out.println("The available item are : ");
    System.out.println("1. Phones");
    System.out.println("2. Televisions");
    System.out.println("3. Clothes");
    System.out.println("4. Books");
    System.out.println("5. Groceries");
    System.out.println("6. Sports");
    System.out.println("**************************************************************************************************************");
}}

