package Items;
import java.util.*;

public class AvailablePhones extends Price implements Rating {
    Scanner in = new Scanner(System.in);
    
    public void ListOfPhones(){
        System.out.println("Phones Available : ");
        System.out.println("1. Apple iPhone 14");
        System.out.println("2. Redmi MI");
        System.out.println("3. One Plus");
        System.out.println("4. Micromax");
        System.out.println("5. Oppo");
        System.out.println("6. Samsung");
        System.out.println("7. RealMe");
        System.out.println("8. Nokia");
        System.out.println("9. Vivo");
        System.out.println("---------------------------------------------------------------------------");

        System.out.println("Enter the choice number of your Clothes ");
        
        int choice = in.nextInt();
        switch (choice) {
        case 1:
            System.out.println("Price of Apple iPhone 14 : " +  Apple_iPhone);
            break;
        case 2:
            System.out.println("Price of Redmi MI : " + Redmi_MI);
            break;
        case 3:
            System.out.println("Price of One Plus : " + One_Plus);
            break;
        case 4:
            System.out.println("Price of Micromax : " + Micromax);
            break;
        case 5:
            System.out.println("Price of Oppo : " + Oppo);
            break;
        case 6:
            System.out.println("Price of Samsung : " + Samsung);
            break;
        case 7:
            System.out.println("Price of RealMe : " + RealMe);
            break;
        case 8:
            System.out.println("Price of Nokia :  " + Nokia);
            break;
        case 9:
            System.out.println("Vivo :  " + Vivo);
            break;
        default:
            System.out.println("Wrong Input");
        }
        System.out.println("************************************************************************************************************");

        System.out.println("Do you want to buy ? Press 1:");
        System.out.println("************************************************************************************************************");
        System.out.println("1. Yes");
        System.out.println("2. No");
        int buy = in.nextInt();
        
                if(buy == 1)
                {
                    System.out.println("*************************---------------------*******************************");
                    System.out.println("***********************|  Buying Successful!  |******************************");
                    System.out.println("*************************---------------------*******************************");
                }
                else
                {
                    System.out.println("We will be waiting for you! Come back Soon");
                }
    }
    public void RateUs(){
        
        System.out.println("On the scale of 1 to 5, Please rate our Phones.");
        int r = in.nextInt();
        System.out.println("************************************************************************************************************");
        System.out.println("Your rated " + r + " out of 5. Thankyou for your feedback");
        System.out.println("************************************************************************************************************");
    }
    public void Greet(){
        System.out.println("THANKYOU AND HAVE A GREAT DAY HEAD! ");
    }

}