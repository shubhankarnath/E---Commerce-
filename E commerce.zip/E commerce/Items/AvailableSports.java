package Items;

import java.util.*;

public class AvailableSports extends Price {
    Scanner in = new Scanner(System.in);
    public void AvailableSportsItems (){
        System.out.println("sports Available : ");
        System.out.println("1. Cricket bat : ");
        System.out.println("2. Hockey : " );
        System.out.println("3. Badminton : ");
        System.out.println("4. Football : " );
        System.out.println("5. Cricket ball : " );
        System.out.println("6. Volleyball : ");
        System.out.println("7. Tennis : " );
        System.out.println("8. Table_tennis : ");
        System.out.println("9. Archery  : " );
        System.out.println("10. Bowling : ");
        System.out.println("11. Carrom : " );
        System.out.println("12. Chess : ");
        System.out.println("13. diving : ");
        System.out.println("14. Golf : " );
        System.out.println("---------------------------------------------------------------------------");
        

        System.out.println("Enter the choice number of your book");
        
        int choice = in.nextInt();
        switch(choice){
            case 1: 
            System.out.println("The price of Cricket bat : Rs. " + Bat);
            break;
            case 2: 
            System.out.println("The price of Hockey : Rs. " + Hockey);
            break;
            case 3: 
            System.out.println("The price of Badminton : Rs. " + Badminton);
            break;
            case 4: 
            System.out.println("The price of Football : Rs. " + Football);
            break;
            case 5: 
            System.out.println("The price of Cricket ball : Rs. " + ball);
            break;
            case 6: 
            System.out.println("The price of Volleyball : Rs. " + Volleyball);
            break;
            case 7: 
            System.out.println("The price of Tennis : Rs. " + Tennis);
            break;
            case 8: 
            System.out.println("The price of Table_tennis : Rs. " + Table_tennis);
            break;
            case 9: 
            System.out.println("The price of Archery  : Rs. " + Archery);
            break;
            case 10: 
            System.out.println("The price of Bowling : Rs. " + Bowling);
            break;
            case 11: 
            System.out.println("The price of Carrom : Rs. " + Carrom);
            break;
            case 12: 
            System.out.println("The price of Chess : Rs. " + Chess);
            break;
            case 13: 
            System.out.println("The price of diving : Rs. " + diving);
            break;
            case 14: 
            System.out.println("The price of Golf : Rs. " + Golf);
            break;
            default :
            System.out.println("Wrong Input");
        }
        System.out.println("************************************************************************************************************");

        System.out.println("Do you want to buy ? Press 1:");
        System.out.println("************************************************************************************************************");
        System.out.println("1. Yes");
        System.out.println("2. No");
        int buy = in.nextInt();
        
                if(buy == 1)
                {
                    System.out.println("*************************---------------------*******************************");
            System.out.println("***********************|  Buying Successful!  |******************************");
            System.out.println("*************************---------------------*******************************");}
                else
                {
                    System.out.println("We will be waiting for you! Come back Soon");
                }
    }
    public void RateUs(){
        
        System.out.println("On the scale of 1 to 5, Please rate our Sport Item.");
        int r = in.nextInt();
        System.out.println("************************************************************************************************************");
        System.out.println("Your rated " + r + " out of 5. Thankyou for your feedback");
        System.out.println("************************************************************************************************************");
    }
    public void Greet(){
        System.out.println("THANKYOU AND HAVE A GREAT DAY HEAD! ");
    }



    }
    

    

