package Items;
import java.util.*;

public class AvailableTV extends Price implements Rating {
    Scanner in = new Scanner(System.in);
    public void ListofTVs(){
        System.out.println("Available Televisions : ");
        System.out.println("1. Samsung : ");
        System.out.println("2. Lenovo ");
        System.out.println("3. MI ");
        System.out.println("4. Micromax ");
        System.out.println("5. One Plus ");
        System.out.println("6. Apple ");
        System.out.println("---------------------------------------------------------------------------");
        

        System.out.println("Enter the choice number of your TV");
        
        int choice = in.nextInt();
        switch(choice){
            case 1: 
            System.out.println("Price of Samsung : " + SamsungTV);
            break;
            case 2: 
            System.out.println("Price of Lenovo : " + LenovoTV);
            break;
            case 3: 
            System.out.println("Price of MI : " + MI_TV);
            break;
            case 4: 
            System.out.println("Price of Micromax : " + MicromaxTV);
            break;
            case 5: 
            System.out.println("Price of One Plus : " + One_Plus_TV);
            break;
            case 6: 
            System.out.println("Price of Apple : " + AppleTV);
            break;
            

        }
        System.out.println("************************************************************************************************************");

        System.out.println("Do you want to buy ? Press 1:");
        System.out.println("************************************************************************************************************");
        System.out.println("1. Yes");
        System.out.println("2. No");
        int buy = in.nextInt();
        
                if(buy == 1)
                {
                    System.out.println("*************************---------------------*******************************");
            System.out.println("***********************|  Buying Successful!  |******************************");
            System.out.println("*************************---------------------*******************************");
                }
                else
                {
                    System.out.println("We will be waiting for you! Come back Soon");
                }
    }
    public void RateUs(){
        
        System.out.println("On the scale of 1 to 5, Please rate our Television.");
        int r = in.nextInt();
        System.out.println("************************************************************************************************************");
        System.out.println("Your rated " + r + " out of 5. Thankyou for your feedback");
        System.out.println("************************************************************************************************************");
    }
    public void Greet(){
        System.out.println("THANKYOU AND HAVE A GREAT DAY HEAD! ");
    }
}
