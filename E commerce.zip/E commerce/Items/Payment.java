package Items;

import java.util.Scanner;

public class Payment {
    public void pay(){
        try{
        Scanner sc  = new Scanner(System.in);
        System.out.println("");
        System.out.println("");
        System.out.println("Choose payment option");
        System.out.println("1. Internet Banking");
        System.out.println("2. Debit Card/Credit Card");
        System.out.println("3. Cash on Delivery");
        int a = sc.nextInt();
        
        if(a == 1)
        {
            System.out.println("Enter your UserID");
            int s = sc.nextInt();
            System.out.println("");
            System.out.println("Enter password");
            String d = sc.next();
            
            System.out.println("Paymetent Successful... We will deliver to you soon");

        }
        else if(a == 2)
        {
            System.out.println("Enter the Debit/Credit card Number");
            int k = sc.nextInt();
            System.out.println("");
            System.out.println("Enter Name of the Card Holder");
            String r = sc.nextLine();
            System.out.println("");
            System.out.println("Enter the OTP");
            int o = sc.nextInt();
            System.out.println("Payment Successful... We will deliver to you soon");

        }
        else if(a == 3)
        {
            System.out.println("We will deliver to you soon");
        }}
        catch(Exception e){
            e.printStackTrace();
        }
        
    }
    
}
