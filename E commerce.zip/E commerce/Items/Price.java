package Items;

public class Price {

        // Phones

        protected int Apple_iPhone = 100999;
        protected int Redmi_MI = 15999;
        protected int One_Plus = 50999;
        protected int Micromax = 10999;
        protected int Oppo = 15000;
        protected int Samsung = 20000;
        protected int RealMe = 14000;
        protected int Nokia = 13999;
        protected int Vivo = 17899;

        // Clothes

        protected int Jeans = 2999;
        protected int T_Shirt = 599;
        protected int Shawl = 899;
        protected int Lehenga_Cholis = 799;
        protected int arees = 29999;
        protected int Sleepwear = 899;
        protected int Tracksuits = 1000;
        protected int Jackets = 49999;
        protected int Sweaters = 2999;

        // Books

        protected int Java_Expert = 499;
        protected int Java_Balagurus = 899;
        protected int Core_Java_and_Advanced = 699;
        protected int Think_and_Grow = 199;
        protected int E_Balagurswamy_DSA = 499;
        protected int The_Complete_Refer = 799;
        protected int DSA_Easy = 699;
        protected int Coding_Interview = 999;
        protected int Advanced_DSA = 1299;

        // Television

        protected int SamsungTV = 49999;
        protected int LenovoTV = 29999;
        protected int MI_TV = 40000;
        protected int MicromaxTV = 15999;
        protected int One_Plus_TV = 45999;
        protected int AppleTV = 99999;

        // Groceries

        protected int Tea = 99;
        protected int Coffee = 129;
        protected int Maggie = 20;
        protected int Cheese = 100;
        protected int Biscuits = 50;
        protected int Aatta = 100;

        // Sports

        protected int Bat = 5445 ;
        protected int Hockey = 4323;
        protected int Badminton = 3000;
        protected int Football = 2000;
        protected int ball = 500;
        protected int Volleyball = 799 ;
        protected int Tennis = 1000;
        protected int Table_tennis = 2000;
        protected int Archery = 3000;
        protected int Bowling = 2789;
        protected int Carrom = 1000;
        protected int Chess = 200;
        protected int diving = 2800;
        protected int Golf = 10000;

}
