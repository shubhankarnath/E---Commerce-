package Items;
interface Rating {
    void RateUs();
    void Greet();
}
