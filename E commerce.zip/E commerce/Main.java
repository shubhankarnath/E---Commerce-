import Credentials.*;
import Items.*;
import java.util.*;

public class Main {

    public static void main(String args[]) {
        try {
            int c = 0;
            Scanner in = new Scanner(System.in);
            Signup sign = new Signup();
            Login l = new Login();

            while (true) {

                l.SignUp();

                l.EnterLoginDetails();

                if (l.check()) {

                    AvailableItems i = new AvailableItems();
                    System.out.println(" ---------------------------");
                    System.out.println("|  Enter Our Choice........ |");
                    System.out.println(" ---------------------------");
                    i.showAvailableItems();
                    int a = 0;

                    a = in.nextInt();

                    if (a == 1) {
                        AvailablePhones m = new AvailablePhones();
                        m.ListOfPhones();
                        Payment p = new Payment();
                        p.pay();
                        m.RateUs();
                    } else if (a == 2) {
                        AvailableTV tv = new AvailableTV();
                        tv.ListofTVs();
                        Payment p = new Payment();
                        p.pay();
                        tv.RateUs();
                    } else if (a == 3) {
                        AvailableClothes cloth = new AvailableClothes();
                        cloth.ListOfClothes();
                        Payment p = new Payment();
                        p.pay();
                        cloth.RateUs();

                    } else if (a == 4) {
                        AvailableBooks book = new AvailableBooks();
                        book.ListOfBooks();
                        Payment p = new Payment();
                        p.pay();
                        book.RateUs();

                    } else if (a == 5) {
                        AvailableGroceries g = new AvailableGroceries();
                        g.ListofGroceriess();
                        Payment p = new Payment();
                        p.pay();
                        g.RateUs();
                    } else if (a == 6) {
                        AvailableSports s = new AvailableSports();
                        s.AvailableSportsItems();
                        Payment p = new Payment();
                        p.pay();
                        s.RateUs();
                    } else {
                        System.out.println("---------------------------------------");
                        System.out.println("|Opps! Please enter the Correct Number |");
                        System.out.println("---------------------------------------");
                        continue;

                    }

                    System.out.println("-------------------------------");
                    System.out.println("|Press 1 to return to Main Menu|");
                    System.out.println("-------------------------------");
                    System.out.println(" -----------------------------");
                    System.out.println("| Press 2 to Exit the Program |");
                    System.out.println(" -----------------------------");
                    c = in.nextInt();

                    if (c == 1) {
                        continue;
                    } else if (c == 2) {
                        break;
                    }
                } else {
                    System.out.println("Wrong Login Details");
                    continue;
                }

            }
        } catch (Exception e) {
            System.out.println("An error occured!");
            System.err.print(e);
        }

    }
}
